# Cardinal Examples

You can run the examples individually or as a demo:

- install cardinal: `npm install cardinal`
- explore cardinal: `npm explore cardinal`
- run the demo: `npm run demo`
