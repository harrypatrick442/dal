declare function isBuffer(obj: any): boolean
export = isBuffer
